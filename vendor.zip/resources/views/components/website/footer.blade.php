<div class="w-footer text-white d-flex align-items-center">
    <div class="container d-flex justify-content-center gap-4">
        <div class="copyright">
            © 2023 K.S. Azim
        </div>
        <div class="socials d-flex gap-4">
            <i class="fa-brands fa-facebook"></i>
            <i class="fa-brands fa-twitter"></i>
            <i class="fa-brands fa-youtube"></i>
            <i class="fa-brands fa-instagram"></i>
        </div>
    </div>
</div>