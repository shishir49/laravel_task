@extends('layouts.dashboardLayout')

@section('content')
<p class="display-6 text-center m-4">Welcome !</p>
@endsection