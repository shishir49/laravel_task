@extends('layouts.dashboardLayout')

@section('content')
hi
@endsection